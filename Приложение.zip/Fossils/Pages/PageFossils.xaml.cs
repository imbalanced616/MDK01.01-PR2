﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFossils.xaml
    /// </summary>
    public partial class PageFossils : Page
    {
        public PageFossils()
        {
            InitializeComponent();
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
        }

        private void MenuAddFossil_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageFossils(null));
        }

        private void MenuEditFossil_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageFossils((FossilsBD)DtgSQLF.SelectedItem));
        }

        private void MenuDelFossil_Click(object sender, RoutedEventArgs e)
        {
            var fossilsForRemoving = DtgSQLF.SelectedItems.Cast<FossilsBD>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {fossilsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().FossilsBD.RemoveRange(fossilsForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionSales_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSales());
        }

        private void BtnTransitionDeposits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }

        private void MenuUpdateFossil_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
            txbSearchFossil.Clear();
            txbSearchTypeFossil.Clear();
            spSearchFossil.Visibility = Visibility.Hidden;
            spSearchTypeFossil.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortFossil1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.OrderBy(x => x.Fossil).ToList();
        }

        private void MenuSortFossil2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.OrderByDescending(x => x.Fossil).ToList();
        }

        private void MenuFilterAD1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.ApproximateDemand >= 0 && x.ApproximateDemand <= 50000).ToList();
        }

        private void MenuFilterAD2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.ApproximateDemand >= 51000 && x.ApproximateDemand <= 100000).ToList();
        }

        private void MenuFilterAD3_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.ApproximateDemand >= 100001 && x.ApproximateDemand <= 150000).ToList();
        }

        private void MenuFilterAD4_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.ApproximateDemand >= 150001 && x.ApproximateDemand <= 200000).ToList();
        }

        private void MenuFilterAD5_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.ApproximateDemand >= 200001).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
        }

        private void MenuSearchF_Click(object sender, RoutedEventArgs e)
        {
            spSearchFossil.Visibility = Visibility.Visible;
        }

        private void MenuSearchTF_Click(object sender, RoutedEventArgs e)
        {
            spSearchTypeFossil.Visibility = Visibility.Visible;
        }

        private void MenuSearchInvisible_Click(object sender, RoutedEventArgs e)
        {
            spSearchFossil.Visibility = Visibility.Hidden;
            spSearchTypeFossil.Visibility = Visibility.Hidden;
        }

        private void txbSearchFossil_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLF.ItemsSource != null) DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.Fossil.ToLower().Contains(txbSearchFossil.Text.ToLower())).ToList();
            if (txbSearchFossil.Text.Count() == 0) DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (spSearchFossil.Visibility == Visibility.Hidden && spSearchTypeFossil.Visibility == Visibility.Hidden)
            {
                spSearchFossil.Visibility = Visibility.Visible;
                spSearchTypeFossil.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                txbSearchFossil.Clear();
                txbSearchTypeFossil.Clear();
                spSearchFossil.Visibility = Visibility.Hidden;
                spSearchTypeFossil.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbSearchTypeFossil_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLF.ItemsSource != null) DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.Where(x => x.TypeFossil.ToLower().Contains(txbSearchTypeFossil.Text.ToLower())).ToList();
            if (txbSearchTypeFossil.Text.Count() == 0) DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
        }
    }
}
