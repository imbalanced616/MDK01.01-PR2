﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageSales.xaml
    /// </summary>
    public partial class AddPageSales : Page
    {
        private Sales _currentSales = new Sales();
        public AddPageSales(Sales selectedSale)
        {
            InitializeComponent();
            if (selectedSale != null)
            {
                _currentSales = selectedSale;
                TitletxtSales.Text = "Изменение продажи";
                BtnAddSale.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentSales;
        }

        private void BtnAddSale_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentSales.FossilsBD.Fossil)) error.AppendLine("Укажите ископаемое");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentSales.CostPerUnit))) error.AppendLine("Укажите себестоимость за единицу");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentSales.PricePerUnit))) error.AppendLine("Укажите цену за единицу");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentSales.IDSale == 0)
            {
                MiningEntitiesDB.GetContext().Sales.Add(_currentSales);
                try
                {
                    MiningEntitiesDB.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageSales());
                    MessageBox.Show("Новая продажа успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    MiningEntitiesDB.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageSales());
                    MessageBox.Show("Продажа успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSales());
        }
    }
}
