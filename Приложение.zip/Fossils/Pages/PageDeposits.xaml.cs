﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDeposits.xaml
    /// </summary>
    public partial class PageDeposits : Page
    {
        public PageDeposits()
        {
            InitializeComponent();
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
        }

        private void MenuAddDeposit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageDeposits(null));
        }

        private void MenuEditDeposit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageDeposits((Deposits)DtgSQLD.SelectedItem));
        }

        private void MenuDelDeposit_Click(object sender, RoutedEventArgs e)
        {
            var depositsForRemoving = DtgSQLD.SelectedItems.Cast<Deposits>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {depositsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().Deposits.RemoveRange(depositsForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionSales_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSales());
        }

        private void BtnTransitionFossils_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }

        private void MenuUpdateDeposit_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
            txbSearchDeposit.Clear();
            txbSearchFossil.Clear();
            spSearchDeposit.Visibility = Visibility.Hidden;
            spSearchFossil.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortDeposits1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.OrderBy(x => x.Deposit).ToList();
        }

        private void MenuSortDeposits2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.OrderByDescending(x => x.Deposit).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
        }

        private void MenuFilterAP1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.AnnualProduction >= 0 && x.AnnualProduction <= 50000).ToList();
        }

        private void MenuFilterAP2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.AnnualProduction >= 50001 && x.AnnualProduction <= 100000).ToList();
        }

        private void MenuFilterAP3_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.AnnualProduction >= 100001 && x.AnnualProduction <= 150000).ToList();
        }

        private void MenuFilterAP4_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.AnnualProduction >= 150001 && x.AnnualProduction <= 200000).ToList();
        }

        private void MenuFilterAP5_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.AnnualProduction >= 200001).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (spSearchDeposit.Visibility == Visibility.Hidden && spSearchFossil.Visibility == Visibility.Hidden)
            {
                spSearchDeposit.Visibility = Visibility.Visible;
                spSearchFossil.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                txbSearchDeposit.Clear();
                txbSearchFossil.Clear();
                spSearchDeposit.Visibility = Visibility.Hidden;
                spSearchFossil.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbSearchDeposit_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLD.ItemsSource != null) DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.Deposit.ToLower().Contains(txbSearchDeposit.Text.ToLower())).ToList();
            if (txbSearchDeposit.Text.Count() == 0) DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
        }

        private void txbSearchFossil_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLD.ItemsSource != null) DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.Where(x => x.FossilsBD.Fossil.ToLower().Contains(txbSearchFossil.Text.ToLower())).ToList();
            if (txbSearchFossil.Text.Count() == 0) DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
        }
    }
}
