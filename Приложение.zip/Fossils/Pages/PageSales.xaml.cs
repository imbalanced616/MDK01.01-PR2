﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSales.xaml
    /// </summary>
    public partial class PageSales : Page
    {
        public PageSales()
        {
            InitializeComponent();
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
        }

        private void MenuAddSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales(null));
        }

        private void MenuEditSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales((Sales)DtgSQLS.SelectedItem));
        }

        private void MenuDelSale_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = DtgSQLS.SelectedItems.Cast<Sales>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().Sales.RemoveRange(salesForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionDeposits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }

        private void BtnTransitionFossils_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }

        private void MenuUpdateSales_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
            txbSearchFossil.Clear();
            spSearchFossil.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortCostFossil1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.OrderBy(x => x.FossilsBD.Fossil).ToList();
        }

        private void MenuSortCostFossil2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.OrderByDescending(x => x.FossilsBD.Fossil).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
        }

        private void MenuFilterPPU1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.PricePerUnit >= 0 && x.PricePerUnit <= 100).ToList();
        }

        private void MenuFilterPPU2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.PricePerUnit >= 101 && x.PricePerUnit <= 200).ToList();
        }

        private void MenuFilterPPU3_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.PricePerUnit >= 201 && x.PricePerUnit <= 300).ToList();
        }

        private void MenuFilterPPU4_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.PricePerUnit >= 301 && x.PricePerUnit <= 400).ToList();
        }

        private void MenuFilterPPU5_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.PricePerUnit >= 401).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (spSearchFossil.Visibility == Visibility.Hidden)
            {
                spSearchFossil.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                txbSearchFossil.Clear();
                spSearchFossil.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbSearchFossil_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLS.ItemsSource != null) DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.Where(x => x.FossilsBD.Fossil.ToLower().Contains(txbSearchFossil.Text.ToLower())).ToList();
            if (txbSearchFossil.Text.Count() == 0) DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
        }
    }
}
